#include <stdio.h>

void funcao();

int main() {
	printf("Ola!\n");
	funcao();
	printf("Adeus!\n");
	return 0;
}
