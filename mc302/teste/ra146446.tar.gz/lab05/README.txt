How to execute:
include package lab05 in eclipse and Run lab05.java as Java Application