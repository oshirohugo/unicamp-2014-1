#include <stdio.h>
void funcao() {
	printf("Estou no arquivo 2!\n");
}
